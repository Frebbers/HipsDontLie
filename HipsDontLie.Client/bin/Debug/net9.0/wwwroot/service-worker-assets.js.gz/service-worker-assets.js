self.assetsManifest = {
  "version": "NqraGMuY",
  "assets": [
    {
      "hash": "sha256-OijFBvy/bKNmh8f+BF+5feBwXvHYoe/Nd0RO44Q/si8=",
      "url": "HipsDontLie.Client.styles.css"
    },
    {
      "hash": "sha256-pE+yIieFSRqqYb3bbqRIB8TxrRBQ20IlYuDagT0yy54=",
      "url": "_framework/HipsDontLie.Client.8t8bfoeohf.pdb"
    },
    {
      "hash": "sha256-/1xzScmKSVM6b38eUKSoHnc0GI2ke2y0IKqxK1K+Qo0=",
      "url": "_framework/HipsDontLie.Client.n22m9wo0n2.wasm"
    },
    {
      "hash": "sha256-yYjnO/gZzTqs4YUGF/xO5furBCf0K42+bjL2aHNWqdQ=",
      "url": "_framework/HipsDontLie.Shared.jho5olu0iu.pdb"
    },
    {
      "hash": "sha256-+O4QOl3BFrvncBQ84AQHc7kPeeoK/Fmf9Rgr3AvtvwE=",
      "url": "_framework/HipsDontLie.Shared.kh1609kznh.wasm"
    },
    {
      "hash": "sha256-h2pKkq57/vS3mbEFyiqoupHb66C30OMHzjlzDqfbD40=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.tnyc7xpluy.wasm"
    },
    {
      "hash": "sha256-cp3828JD1TdnmZ6g3GEfXKayNKd2ljfibH3wdg6t3n0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.up1bcx14yi.wasm"
    },
    {
      "hash": "sha256-+uXtoXpMFQKIFs1SOag/WdIbA4G4Q4eGRRGFCiXIBdU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ip3tel2wdp.wasm"
    },
    {
      "hash": "sha256-tChPBLUd3b2CpuaUBQ2hV/OoJbb5XPFpVtYTXo46Y+o=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.grj5cmg1s5.wasm"
    },
    {
      "hash": "sha256-6X0P9WizrWIhvvQG4Dceipzc7UdF1QjvXKoTLrIrvkQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.t32damlu4o.wasm"
    },
    {
      "hash": "sha256-2HidT0I32ow5YfrM4vAJvUicfg2Vo4Eoi+DptVHr868=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.srjvbq70j7.wasm"
    },
    {
      "hash": "sha256-r7YS8Hp01zUR3LoH5JsS7IrucOta+FnV199bCLii7Pk=",
      "url": "_framework/Microsoft.CSharp.j3zkownjjr.wasm"
    },
    {
      "hash": "sha256-mjL5HgHF+Cdm3ucrD6EN+wSQD8HioaniVQtthpAQYSc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.2q3rnwzz6j.wasm"
    },
    {
      "hash": "sha256-d2m6d3omvAahzcHL3zC2w13VYR+3KnIqvZ0XljyLQ7U=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.p8da152h7a.wasm"
    },
    {
      "hash": "sha256-SLUX613Faf3h+89DtEjMhEPQuTCYpIeP01yxJqPtat8=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.0usfjilh8o.wasm"
    },
    {
      "hash": "sha256-BS9j7ySwg+tF6JWEwBlXKkHexM4FMzuzCvSI1M6DPWc=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.5goloas6bj.wasm"
    },
    {
      "hash": "sha256-0+9f7KUt7EiUlYtUes59HkDRvApZYrmtIXGYxCLzedw=",
      "url": "_framework/Microsoft.Extensions.Configuration.xr05dk02yv.wasm"
    },
    {
      "hash": "sha256-jvaipHw61+4HriYJufCdZBXJB/gIRUpw/Fbdei1E6uI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.6epwuw9flx.wasm"
    },
    {
      "hash": "sha256-Ob5mJm5+xBW1boS+gCn51SZeE8WX1De0hKqTqDVOYp8=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.rfhuu8p4w7.wasm"
    },
    {
      "hash": "sha256-x/CuPEnQghJZjvCoNM5EeSCbJmL15vo69CKIuDOZFPE=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.f6m2kkjm8i.wasm"
    },
    {
      "hash": "sha256-tzn/o5v06hK2rtONV2cONytvI9iIwXkV/v+YzhNfgFs=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.pwje2iqgsz.wasm"
    },
    {
      "hash": "sha256-r41/JeKa5jEf6LWlsMhzQi8XEzGTVv3gpBIzZ5gmb9k=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.fw6n3iiewj.wasm"
    },
    {
      "hash": "sha256-j9i4Xe9suFGLFqWXzJGAeHxExSzCNS9FtfYHXVpTfHQ=",
      "url": "_framework/Microsoft.Extensions.Logging.9y6pcj4d20.wasm"
    },
    {
      "hash": "sha256-5MnhuLW3xfcFQsozdjut5urShGXYw6iwlOrJurBV+Y4=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.4svgpfnsk6.wasm"
    },
    {
      "hash": "sha256-BBTw+Wjj2UjzIJocSmODJubcSeoE4u6tl7px+blJYuQ=",
      "url": "_framework/Microsoft.Extensions.Options.wf856ft4x9.wasm"
    },
    {
      "hash": "sha256-Elg5wky4vBTrdLSaUEXuDf9cABTJVOMgNdzYRIjyBF8=",
      "url": "_framework/Microsoft.Extensions.Primitives.6ymn4wtgeh.wasm"
    },
    {
      "hash": "sha256-AHeFn5IBMJC1tI8hRNTBa4lyLko5J8AK64JFjeO/vVw=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.c5whsk6cyh.wasm"
    },
    {
      "hash": "sha256-8KHde87s03YXh21jjvaLX0OAjPTeWpKn1jV7kf9GrvM=",
      "url": "_framework/Microsoft.JSInterop.oafygsa2yv.wasm"
    },
    {
      "hash": "sha256-/jlp74GLHWhrCfjAmWlVClO68H3wIk+kVx9A/gjByls=",
      "url": "_framework/Microsoft.VisualBasic.Core.qljjwgjnrn.wasm"
    },
    {
      "hash": "sha256-eNtd5fm3g/oUf5hiuJ1DpH74Qzd5eTxbpPOEunY0DZQ=",
      "url": "_framework/Microsoft.VisualBasic.ocn5mkr2m2.wasm"
    },
    {
      "hash": "sha256-7cSlpviPeI+Vg0UyzN+/WIuffsrw8/mA+yvYyWejeM4=",
      "url": "_framework/Microsoft.Win32.Primitives.fhyyo0saa3.wasm"
    },
    {
      "hash": "sha256-c5UPAB7GQbMTy7sOEkPdYy4aL8tTvkFYw9ZJakHT1SM=",
      "url": "_framework/Microsoft.Win32.Registry.nbxzikm6ra.wasm"
    },
    {
      "hash": "sha256-/I6jhbBWOR/lWglc7Rxpwv34dmUTZap2GRZ8U5MUw+4=",
      "url": "_framework/System.AppContext.s2mli7k045.wasm"
    },
    {
      "hash": "sha256-TRLW74tFyYdejiCs6uJIuxPhS/Rh0NTqVByoAZ5fZTQ=",
      "url": "_framework/System.Buffers.d8ayacj23s.wasm"
    },
    {
      "hash": "sha256-eXJFjPOfQTz1QrzxB0jB5+oztcrSuo+W7zIl7oEUM6I=",
      "url": "_framework/System.Collections.Concurrent.feo024siyp.wasm"
    },
    {
      "hash": "sha256-bQcUlgX5DIF6Qdkh3Hz+sTbgMGdWPLYdy4dhUDp8xbk=",
      "url": "_framework/System.Collections.Immutable.hn2kphqqyx.wasm"
    },
    {
      "hash": "sha256-KIS6tIStO5vU3qfSwAM5/FUNiiiOPd10UgKjsTR4BEM=",
      "url": "_framework/System.Collections.NonGeneric.get8583r4q.wasm"
    },
    {
      "hash": "sha256-OhhcaU1wzF4qnEyt41wYiRkv9TrGPhK2+Fp9HBW3Kss=",
      "url": "_framework/System.Collections.Specialized.y21ri2wtjp.wasm"
    },
    {
      "hash": "sha256-avYK9JiIHAt960tqSZ6qgSA1BonSZcBQA6QGsJsolIo=",
      "url": "_framework/System.Collections.ejndmmtq8p.wasm"
    },
    {
      "hash": "sha256-GfMz8B2CdRhiHWW4+2lZBhhVOIhwP+XqE2FbtFvjWNw=",
      "url": "_framework/System.ComponentModel.9oz2etf2o8.wasm"
    },
    {
      "hash": "sha256-nXXlnLfKy/z9ZtGYq6KQquFihMIr6VhA6L/gqc9BAfI=",
      "url": "_framework/System.ComponentModel.Annotations.v1y4pnhy9x.wasm"
    },
    {
      "hash": "sha256-gNJtHXrkqglzl9wtWSYjmKsZB/dpV60tUF4XTn/lCoE=",
      "url": "_framework/System.ComponentModel.DataAnnotations.4n446zbohc.wasm"
    },
    {
      "hash": "sha256-8V3Cv7svrNJUOyC5XLddLH+Cn/Ykt1JItuoYWrT3NXQ=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.xwxd57h7as.wasm"
    },
    {
      "hash": "sha256-Wzyay5RYXulOzzOW4lRc3cfKYEDxx2kRvEsC7s04jC8=",
      "url": "_framework/System.ComponentModel.Primitives.r00dr8i32r.wasm"
    },
    {
      "hash": "sha256-KKR2VKkM2u6+glcHst5G2sOlhQKfjtl5Clut1lK0f3A=",
      "url": "_framework/System.ComponentModel.TypeConverter.41zy6wf9oa.wasm"
    },
    {
      "hash": "sha256-UMCTdZNJl+DpifSTm7JTX9MiDveaGx0YdDe26vmve1M=",
      "url": "_framework/System.Configuration.8efnux55ll.wasm"
    },
    {
      "hash": "sha256-D86swTXipVR8ybg6FaZ5abi6e25eL9G07fJtKJo0A+U=",
      "url": "_framework/System.Console.z3svuovkyl.wasm"
    },
    {
      "hash": "sha256-GnOGHVyLg+xDCUaAvFHYZzxFGRP83uFv1xvOMpIBJdA=",
      "url": "_framework/System.Core.i2gfsit2dg.wasm"
    },
    {
      "hash": "sha256-hWLdNFAs0itxe0epW/MxipXKxOxL86uUSbroosNAIXo=",
      "url": "_framework/System.Data.Common.15xzwwriko.wasm"
    },
    {
      "hash": "sha256-NTsqFBiGrsnsvNxSeHOCHtX3ir5NovlbWjPDLWAEqfs=",
      "url": "_framework/System.Data.DataSetExtensions.rwrekrq7sx.wasm"
    },
    {
      "hash": "sha256-bQe+JUXWGsr3SCnFt55wkmSf5WX0Q9UY7K4jU07ofCs=",
      "url": "_framework/System.Data.jc9hvsoz9b.wasm"
    },
    {
      "hash": "sha256-5hUC2SI169teraWv79xeyHs6BHlwtcmibtRYUQRIAxc=",
      "url": "_framework/System.Diagnostics.Contracts.m8zapvzysw.wasm"
    },
    {
      "hash": "sha256-/8cm9vLcqMIoH+jYe61m7EG6OYpmxv0+bX7tK5RdrKc=",
      "url": "_framework/System.Diagnostics.Debug.3b311sbro1.wasm"
    },
    {
      "hash": "sha256-/D7/uDNOBAyZLWrMPzw5pzHYAcHYZUjgEzXCkgHTwXg=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.onf7a771xa.wasm"
    },
    {
      "hash": "sha256-y3I8QP6yhvMEaYVGjaCo3RKJ0fDOq+3L7mol9S+SNJI=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.3u9sednzu3.wasm"
    },
    {
      "hash": "sha256-nX4lOaeHse02SkrNl8GNRYrCBQBEXyrHy3KC0/sqoNw=",
      "url": "_framework/System.Diagnostics.Process.pxizkgy5ym.wasm"
    },
    {
      "hash": "sha256-SCRvFZmPh3w+A02sPn1+VGxmWNJJFYidFkMKj92zVj4=",
      "url": "_framework/System.Diagnostics.StackTrace.klgx6zaqgg.wasm"
    },
    {
      "hash": "sha256-NULze4Ko/w/GYqd6g6YdsVCwyyULl/VmSq7PNvdRxtM=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.7lhrolq8ha.wasm"
    },
    {
      "hash": "sha256-JgRxamnubgNju9Ko7p4iEtOvZS0Cj9AWxx9XCB1neUA=",
      "url": "_framework/System.Diagnostics.Tools.i1rtuy3ws8.wasm"
    },
    {
      "hash": "sha256-5I6/dcXCd8N2bYq+TsEcLO4uG88syx0USCuYqf/8mtE=",
      "url": "_framework/System.Diagnostics.TraceSource.su9091p6cd.wasm"
    },
    {
      "hash": "sha256-98KWmM32pxDFBZeoesjCkiG3KLqT2boreDG0vqDS8Pk=",
      "url": "_framework/System.Diagnostics.Tracing.5l18zgsm1q.wasm"
    },
    {
      "hash": "sha256-x8ah4OQOIRyvRGLrUr39hfvLB0w/UVX6fcepy4Q5UhA=",
      "url": "_framework/System.Drawing.Primitives.dbya5q61h6.wasm"
    },
    {
      "hash": "sha256-g++0JBThCnodSqR84eV/iwTjp1iebfwhykE6qsaAjsU=",
      "url": "_framework/System.Drawing.nnz855j4yk.wasm"
    },
    {
      "hash": "sha256-g2fE5CDwpE4AtGRf1Jn5GSTH7Ro5TOVp7TA6QBTygKg=",
      "url": "_framework/System.Dynamic.Runtime.zk5l0u6vqy.wasm"
    },
    {
      "hash": "sha256-Z4nBv2XbdnbGQ+hQnVnFvcXeFhSAAJcMjSZMHhaDWgE=",
      "url": "_framework/System.Formats.Asn1.xadtuo15bu.wasm"
    },
    {
      "hash": "sha256-op3Pbgt05d+9ffS8w/54k6Zdn5nGwAyDHfvIjwWlNDs=",
      "url": "_framework/System.Formats.Tar.maqtwy9rpf.wasm"
    },
    {
      "hash": "sha256-rV6A6XSj+aPnevENU9F3mBTrXfYn/RgHI6xGpURDTuk=",
      "url": "_framework/System.Globalization.Calendars.nnkzew0o11.wasm"
    },
    {
      "hash": "sha256-1Xdj62ar8z+x18w5BwvJefchuoUHBLMAhdfCdfyv+BM=",
      "url": "_framework/System.Globalization.Extensions.vj2hxw2cxd.wasm"
    },
    {
      "hash": "sha256-UBCz8jn3jGY78IxIvMaFFkqV2YHGU2znyiJwdBHph7Y=",
      "url": "_framework/System.Globalization.c1ysxhlm64.wasm"
    },
    {
      "hash": "sha256-A9DFOadSNLJ9DXxQ1d2/mXj4qIfNFWWZifKU+6YOlZY=",
      "url": "_framework/System.IO.Compression.Brotli.v5j03f7yzu.wasm"
    },
    {
      "hash": "sha256-EEoh03Xy9ZNnOSBEfAhFBRhf6syWa2iSfpeoy19KsoU=",
      "url": "_framework/System.IO.Compression.FileSystem.oapcnmb898.wasm"
    },
    {
      "hash": "sha256-pTBYoX4V1Ci5dx/LYY4VkggMiQHByqxl79/tMfiT8Xw=",
      "url": "_framework/System.IO.Compression.ZipFile.n9kbwti3xz.wasm"
    },
    {
      "hash": "sha256-jdNKNdQzumTM0O5zonEHyQbOoTbSEgxacpMhExktkeo=",
      "url": "_framework/System.IO.Compression.nf0x03kqm2.wasm"
    },
    {
      "hash": "sha256-AsJzCZSPS7fAlHAT72XA8D3MbHN4bp5vHwBgGhjVNes=",
      "url": "_framework/System.IO.FileSystem.278u1momgg.wasm"
    },
    {
      "hash": "sha256-6MBZQhzHb3qZno633df0VBEB12I+qassxHKOkReDCtA=",
      "url": "_framework/System.IO.FileSystem.AccessControl.ocpn3fin63.wasm"
    },
    {
      "hash": "sha256-qRDx0fGsoO8xKl7pih9Vh722NLZYASZ6pHRtu9Qm1FM=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.51cn8bey3t.wasm"
    },
    {
      "hash": "sha256-KAyO7YeYtM5XCEmO/E5Tgate5eNh8XRkFt0IzSHFG2I=",
      "url": "_framework/System.IO.FileSystem.Primitives.0ejcvk17nr.wasm"
    },
    {
      "hash": "sha256-vgcwbv+5/M9qzMnYACAvriKeBLAmoLIXsF/teJ+OVDQ=",
      "url": "_framework/System.IO.FileSystem.Watcher.ma8btvnulf.wasm"
    },
    {
      "hash": "sha256-T2K8sA1gBtvOadum4Scw+zwqqPnEmUM+c4xsZeHTVAU=",
      "url": "_framework/System.IO.IsolatedStorage.l76lfbxwit.wasm"
    },
    {
      "hash": "sha256-uZAys5x5I3g7XxzIZbdEXhpTkJSoXxmD1KA4F8bv6Z8=",
      "url": "_framework/System.IO.MemoryMappedFiles.hqsx1g6hyq.wasm"
    },
    {
      "hash": "sha256-Q8Hv4cx0IwCzRVPNPLaVRqSpgqTXwgCrr1K9BY/AfPI=",
      "url": "_framework/System.IO.Pipelines.9500alwmx9.wasm"
    },
    {
      "hash": "sha256-/Iybz6T77Tcznvz1c7MspkjJcNlWSEP+aEQVXyixE+E=",
      "url": "_framework/System.IO.Pipes.AccessControl.c8tonf5uy5.wasm"
    },
    {
      "hash": "sha256-nrjy7gjSwhMtVyHj7zHs2RBqQ7h5fwmxhtoAXXHKQ6c=",
      "url": "_framework/System.IO.Pipes.qp820k9vvz.wasm"
    },
    {
      "hash": "sha256-m4c+SCLmOi2rxzieJrcDVi2n61Gx4Hgyeo8GnQ5sJ9Q=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.te9j6br1cp.wasm"
    },
    {
      "hash": "sha256-zNNJyzSS5xobmQjSvJQ2zYajATFwqTs1v8ocFSAGtlg=",
      "url": "_framework/System.IO.otuf6d74sr.wasm"
    },
    {
      "hash": "sha256-URB5MIkum09zoZL8LIHe2LH6jF4E6OnEHrcP+SZ4Hwg=",
      "url": "_framework/System.Linq.Expressions.9qursg64iq.wasm"
    },
    {
      "hash": "sha256-e7Or1axDGC0vSmHroFlaTdU/o2+q568n+M2vTWmNMss=",
      "url": "_framework/System.Linq.Parallel.f7fejzp6g2.wasm"
    },
    {
      "hash": "sha256-vFEKURslTdWYs+AvQ8+jdZfcYp2e1B+asPfpvQnkcQc=",
      "url": "_framework/System.Linq.Queryable.ksg1f547zn.wasm"
    },
    {
      "hash": "sha256-vTwCfSEU8ZbuEeaf7EDY5xxBmvXmMTtpg/7/1pgdRIw=",
      "url": "_framework/System.Linq.b6i9jn5866.wasm"
    },
    {
      "hash": "sha256-auI2+Ku6fpXBVDEvp93nHAbVA8xRZf4CJQ+0jeaYJoM=",
      "url": "_framework/System.Memory.uyrspy20w7.wasm"
    },
    {
      "hash": "sha256-2CBXOKL4E7bNIT8rKcK2YDKFcDb2OnJCedC2n02tcUY=",
      "url": "_framework/System.Net.Http.Json.osyg7lnynd.wasm"
    },
    {
      "hash": "sha256-A3yXY8sRK7yh/GXsqSFOqtARC1UI5pL4IjrPGc2I1ik=",
      "url": "_framework/System.Net.Http.t88101cxuh.wasm"
    },
    {
      "hash": "sha256-Zap2E0IOWwsX40vo5aoeEiqERvahVPdEqEhOLRha/58=",
      "url": "_framework/System.Net.HttpListener.pjiup6uulr.wasm"
    },
    {
      "hash": "sha256-ufx9prYWbkYfcqAB36G8LSdE/Jxabef0eUISFcm71M0=",
      "url": "_framework/System.Net.Mail.x2t68znxj5.wasm"
    },
    {
      "hash": "sha256-G85CSz07B5WpA1aYfeKTE+mmhSAX9U50HKF2H5hFQv0=",
      "url": "_framework/System.Net.NameResolution.darvipojrr.wasm"
    },
    {
      "hash": "sha256-TSF1TpoZBqNcqCVvHLv/NjCnjEQAOC1c6IoCeoE9tT0=",
      "url": "_framework/System.Net.NetworkInformation.dggc7r1ubt.wasm"
    },
    {
      "hash": "sha256-MINdBnqNIukeKO6dNxCn9D+s5I6UyTH+U6aZacSdBgw=",
      "url": "_framework/System.Net.Ping.s1znquqtyf.wasm"
    },
    {
      "hash": "sha256-9fQnSvxAj3o6ML4TsJP1TkW52T/CA12MLTw/eX0u+MU=",
      "url": "_framework/System.Net.Primitives.t29gzklln2.wasm"
    },
    {
      "hash": "sha256-IPEeSrm359/WHNXGfOAOvO95Tbn3nd8tUeUrxqqEGX8=",
      "url": "_framework/System.Net.Quic.sh2pare3qi.wasm"
    },
    {
      "hash": "sha256-IT5faW7bQHZCJ4HKrwK/BExKU4uABC1kT710E0MudcE=",
      "url": "_framework/System.Net.Requests.hc2hga6pkb.wasm"
    },
    {
      "hash": "sha256-deU4jhzdwvX+me7/stZRUqshePGYlGQVDWz0+Cur9Pg=",
      "url": "_framework/System.Net.Security.fr36up6qj6.wasm"
    },
    {
      "hash": "sha256-dqZI3Xy4ApVATTXSCtphwAlha2dEH8BOPv8uO/zFnTA=",
      "url": "_framework/System.Net.ServicePoint.qn67lxbu1q.wasm"
    },
    {
      "hash": "sha256-xQtdT0g7iIU9Ei024TsEiitUzwGqhCJKT+LBngmgHYg=",
      "url": "_framework/System.Net.Sockets.dijc2jj6vh.wasm"
    },
    {
      "hash": "sha256-uCKw8OsbkEM4MDVb3v13aNO9wjOu8TJjJXjDRc42REI=",
      "url": "_framework/System.Net.WebClient.80b46nh61e.wasm"
    },
    {
      "hash": "sha256-5Yu78J6pPfDSd/6o/v23hW+ZNubvqsvh5ruLaePMt5s=",
      "url": "_framework/System.Net.WebHeaderCollection.3mwc447ji4.wasm"
    },
    {
      "hash": "sha256-7UNes2b5U53/KH7OhSl/vzYGx3b3qXG+xROdb+2taMk=",
      "url": "_framework/System.Net.WebProxy.f1ecer1rjo.wasm"
    },
    {
      "hash": "sha256-VXu3EXZw6DPxx0xts6YS7NdwEsO2+cQF/36SvMzIWBY=",
      "url": "_framework/System.Net.WebSockets.3mhqx26dbt.wasm"
    },
    {
      "hash": "sha256-tkQvMdvh1bNG0tDrS9apjrSGbLfArCqQ7hZzZEQVWwA=",
      "url": "_framework/System.Net.WebSockets.Client.mo091qp4pk.wasm"
    },
    {
      "hash": "sha256-EvEGBQ5J4mf93Oo2ptKUwHiwxAdtT0VIjgT9dVgAhe0=",
      "url": "_framework/System.Net.apmwghm6mr.wasm"
    },
    {
      "hash": "sha256-+gr0le03EWaZBKckJW4qLoZ9CfQt8yxat46SV2hP9ps=",
      "url": "_framework/System.Numerics.Vectors.298h9ayyej.wasm"
    },
    {
      "hash": "sha256-hWyLH7SgVO/RrDluZ1xbViUGWf7SShAKTTZAlxZDt7s=",
      "url": "_framework/System.Numerics.b89n5cbieg.wasm"
    },
    {
      "hash": "sha256-Ks3RY0s3DLqn0BMynjFImzpPgxTZtCbfd4dQIYQHMAY=",
      "url": "_framework/System.ObjectModel.ypzsv8rp7y.wasm"
    },
    {
      "hash": "sha256-dmlLyil2xqdBc+0yMfmACcDeIGVefS4QHjRT/9mLdNs=",
      "url": "_framework/System.Private.CoreLib.uqnhzdwypx.wasm"
    },
    {
      "hash": "sha256-Rc0EMjOAGNZVMGMp7a/meo+E/WEtdkGLerrXHSIGWLg=",
      "url": "_framework/System.Private.DataContractSerialization.5st6hct31n.wasm"
    },
    {
      "hash": "sha256-X0VtWfJWrB0RiMicS+en/0REGgrfDskF0oi4rKGQCfQ=",
      "url": "_framework/System.Private.Uri.nm30bysvuf.wasm"
    },
    {
      "hash": "sha256-MB2XvqmNNjbvsbUbFNfp+GLt7XQcQ73Xrugysgtn8sA=",
      "url": "_framework/System.Private.Xml.Linq.oal8pz22v5.wasm"
    },
    {
      "hash": "sha256-r2tMto8j0V2ICD+ZfGm0QMzInrJgstrjdJxyKGD8Qmg=",
      "url": "_framework/System.Private.Xml.xkmk1pg9kr.wasm"
    },
    {
      "hash": "sha256-k2yyNHv4qCY2kRlotlDQtSIdlL0hlcrZ8gLA3A0CrWY=",
      "url": "_framework/System.Reflection.DispatchProxy.f1qnpwde5z.wasm"
    },
    {
      "hash": "sha256-9ur517/2/ohRn5ZEkSEjrp7JedCBaln0HrZ6wxjNSUc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.yxremw531k.wasm"
    },
    {
      "hash": "sha256-Ka+EZUZgx+thLiWVrn1juZkMPjSo+nhieSBjPxSTFwE=",
      "url": "_framework/System.Reflection.Emit.Lightweight.9wuvl3yjpn.wasm"
    },
    {
      "hash": "sha256-GNB+DFaYHTqWQpuNcmS6hbLwBj9MszLwwCAy5LYoA2U=",
      "url": "_framework/System.Reflection.Emit.wqaeaqpqjx.wasm"
    },
    {
      "hash": "sha256-5VraewcNFUMrbyfvx1X2XHR8TQbtgatio49/ZHGMHa4=",
      "url": "_framework/System.Reflection.Extensions.dabnud1qlu.wasm"
    },
    {
      "hash": "sha256-9rnMU8qxblkTvEH5NmIDt6MAWULqY1heSHfs/FoeJm0=",
      "url": "_framework/System.Reflection.Metadata.mk9ue4xfjz.wasm"
    },
    {
      "hash": "sha256-TUJgiZFe7Ye01zuokcY+kCaMgcpwjW3Z6X0m/I4MvcI=",
      "url": "_framework/System.Reflection.Primitives.v1rf3dtaqo.wasm"
    },
    {
      "hash": "sha256-p2bhPIbD14QbgvSuYUKlki2jQm4iV+3dvpWHmyS+NKY=",
      "url": "_framework/System.Reflection.TypeExtensions.3pqmipm6tn.wasm"
    },
    {
      "hash": "sha256-w2TYXWd1NzN+pgAM0NQXcLUOzB47mNGOlEEGNOkE8LA=",
      "url": "_framework/System.Reflection.riqy6h8m7i.wasm"
    },
    {
      "hash": "sha256-jv+TqgolMFnQ0lpFpmfqB4G6r+kXti7IEUByJ9oP0lE=",
      "url": "_framework/System.Resources.Reader.qab1hgqeqx.wasm"
    },
    {
      "hash": "sha256-twYOOZBCcCU7QML3AQg9KPt8NvGmUBsFYlycCxAKvuQ=",
      "url": "_framework/System.Resources.ResourceManager.3hl45vgzlu.wasm"
    },
    {
      "hash": "sha256-vHIAJF1HQQTB8sCcs4PFNICdAbtPBqox4qVsPqqu3qs=",
      "url": "_framework/System.Resources.Writer.8noae5zjuo.wasm"
    },
    {
      "hash": "sha256-Bid5AWCHHiJrnEtQyRJrsTHfrKQMt8OLRY2W0xfAfIM=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.e23ug3kux4.wasm"
    },
    {
      "hash": "sha256-RPCLk90YLbUbvLYqNYiivnknzR+q6dwiWVnzkHpYuj4=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.0dbz424zo8.wasm"
    },
    {
      "hash": "sha256-5d7YNQL2N79aoduSRinKvD3HiSMKIzivlHBMBPDCKjE=",
      "url": "_framework/System.Runtime.Extensions.te5ibe9mop.wasm"
    },
    {
      "hash": "sha256-qiSGLziqGQsZy4VK8RK87yVZMZQvl+isft9RC7trrVA=",
      "url": "_framework/System.Runtime.Handles.e3jwcwvkfi.wasm"
    },
    {
      "hash": "sha256-lG0G5b5BfyTsUrwowHDjK64bktG5fmJPj5OcXCbiGpI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.4iqhe1sblh.wasm"
    },
    {
      "hash": "sha256-pBLY7JQIzExyXGEMLAWalfxAqtIWIG+LkZTFDey2eeA=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.whqysb3ecz.wasm"
    },
    {
      "hash": "sha256-BJnuxrEQnqs2JscWG+rSuLehIgNpFADcJgm0Zsxfxt0=",
      "url": "_framework/System.Runtime.InteropServices.ksoqlt99hd.wasm"
    },
    {
      "hash": "sha256-7/Dt+ZHBV/Grc41ZBOVBXJSGWUZprQ5Z5LNUhD4/9yY=",
      "url": "_framework/System.Runtime.Intrinsics.5rk8wp9xsl.wasm"
    },
    {
      "hash": "sha256-zy6j2ll8aQk0Nx0fJhnTA/Zg6MMyqOpXBqSSJld1WUg=",
      "url": "_framework/System.Runtime.Loader.ny7ii14wer.wasm"
    },
    {
      "hash": "sha256-eDOI5u8viohOny5uiq6DUf9R8fYCBj/lyzkk1x7MjcU=",
      "url": "_framework/System.Runtime.Numerics.wmwlbkynae.wasm"
    },
    {
      "hash": "sha256-wp6nRQt/GI3TIRz4TftMZ35DFfGYFPxxov6sZyt45mc=",
      "url": "_framework/System.Runtime.Serialization.6y35mmxzrq.wasm"
    },
    {
      "hash": "sha256-Pr92cIXUFQy4CIWeCj3s7vv0Umg/axv6KRfkb29rnyE=",
      "url": "_framework/System.Runtime.Serialization.Formatters.u5rt67plgv.wasm"
    },
    {
      "hash": "sha256-z8jIQBIFNhWsQcAO2L59f4I3Id2e1RtvMYrmBBgZG9A=",
      "url": "_framework/System.Runtime.Serialization.Json.57n7mkio0p.wasm"
    },
    {
      "hash": "sha256-Utlm+wnwovcUicn1MfWMLhbcCs8P2z1LbLFqSQbJh/U=",
      "url": "_framework/System.Runtime.Serialization.Primitives.ygbpnny2mc.wasm"
    },
    {
      "hash": "sha256-HqqjCv03ek6fbWsTRVgce9KpHKRPVSpT5lXjQVat+k4=",
      "url": "_framework/System.Runtime.Serialization.Xml.2widxteaf4.wasm"
    },
    {
      "hash": "sha256-Gd7O9vaVHclDJwEIAyYpW72WOFrbChLF+jJQW803vzM=",
      "url": "_framework/System.Runtime.hexcao080t.wasm"
    },
    {
      "hash": "sha256-216+tSfjiC2HCjvyTaY33dLLWNf4r/QCYGW+6biHFAI=",
      "url": "_framework/System.Security.AccessControl.15bbw5su7q.wasm"
    },
    {
      "hash": "sha256-0DBuvWiuQoLyvXUNNL227LeaLj64fDFdSU/isvyIqUY=",
      "url": "_framework/System.Security.Claims.kjb7p8c8k7.wasm"
    },
    {
      "hash": "sha256-TEqv87/aHO8l5SiD1vu8Bnt5Sg8FU3DJ2hjmWfFKMkk=",
      "url": "_framework/System.Security.Cryptography.0rw6nqo7fz.wasm"
    },
    {
      "hash": "sha256-uxypXOcE4xSlRetgLqCfpg5k21Dj2fRzLLFv93NtbHw=",
      "url": "_framework/System.Security.Cryptography.Algorithms.974cvdn89t.wasm"
    },
    {
      "hash": "sha256-dWhgNSn/0HkvJmZHZIODyRt2TrFg6s2whr0lyNRIze8=",
      "url": "_framework/System.Security.Cryptography.Cng.pvstpifg15.wasm"
    },
    {
      "hash": "sha256-sSvL24LTRfNGEAejuzPa2kDA0AJDkM9R3qa/SRqLiOE=",
      "url": "_framework/System.Security.Cryptography.Csp.9695qhf9yt.wasm"
    },
    {
      "hash": "sha256-I1RBhYNhmFZQbS/CgXtPWRgDkHcA6CPigR8GalhINhk=",
      "url": "_framework/System.Security.Cryptography.Encoding.nrsiudkmau.wasm"
    },
    {
      "hash": "sha256-R6rFjBLKGhEsMxFgDXxc8nnrYGYXOjipKFyqCLKxLds=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.rvhvyfg159.wasm"
    },
    {
      "hash": "sha256-OU7d+OUcaKzB3Ka5c3yUFhL3IPYVBLQ3H5yrdpTIJrU=",
      "url": "_framework/System.Security.Cryptography.Primitives.rz8tfc0zvn.wasm"
    },
    {
      "hash": "sha256-lGiJto46vOvwdi5Gsqezea08o4AeW2FliJYxw4hra3U=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.4694slsze8.wasm"
    },
    {
      "hash": "sha256-Z9bGTVBzUSqT1Y+gGcaK5NHml0aYv+C/IdGhYwq81g8=",
      "url": "_framework/System.Security.Principal.94wgvdpj1g.wasm"
    },
    {
      "hash": "sha256-TghNxN8XXyT9WWIXWUANfkII+Ik/tzZjeNqdXEqsxYk=",
      "url": "_framework/System.Security.Principal.Windows.q6gj72jx8c.wasm"
    },
    {
      "hash": "sha256-+ax3O9/+rqTB08Yfy+Dih+FQ1Xwil4iMhyN/CE7uwAY=",
      "url": "_framework/System.Security.SecureString.z1o1nfpyhv.wasm"
    },
    {
      "hash": "sha256-Y35i5qoCuFmQ2fyZ2MCaDsEY2Kb2sPzt5d3UM/cTnnc=",
      "url": "_framework/System.Security.tg40nloc0f.wasm"
    },
    {
      "hash": "sha256-WTGKO6ipucrqepOhmsPhof3lQhQXyuAhepSNoXzg9h4=",
      "url": "_framework/System.ServiceModel.Web.jxbpi5wlg5.wasm"
    },
    {
      "hash": "sha256-UNjoTGgNCtpbvl0ft6incq3MB7gcxmxzDBuq2f7pb5o=",
      "url": "_framework/System.ServiceProcess.86z5319u6p.wasm"
    },
    {
      "hash": "sha256-2atwpo2dgsqAmmQVTq8AsuqDYsQOk70xLILPq8dxOyk=",
      "url": "_framework/System.Text.Encoding.CodePages.z9scq0q12p.wasm"
    },
    {
      "hash": "sha256-OtsfF9uFHc4Toz+ICupuIIMnsBipNj1Nyt+JRDqHwAU=",
      "url": "_framework/System.Text.Encoding.Extensions.yqrvhbgyzm.wasm"
    },
    {
      "hash": "sha256-XdKhz8cp6QZRyXg8UZiv/mcdfmDDeDrrjEUPPywScAA=",
      "url": "_framework/System.Text.Encoding.pd31zmnukr.wasm"
    },
    {
      "hash": "sha256-A15DBOljXshMaH/5pg1OjPSOP2AhBVC7Gm1LIue95/s=",
      "url": "_framework/System.Text.Encodings.Web.f1xjgsf1dl.wasm"
    },
    {
      "hash": "sha256-HpryzOMtu8dN3tmKGDI6Qgn2/R16vXiBNtbiYyS3t7U=",
      "url": "_framework/System.Text.Json.6absu9hr1f.wasm"
    },
    {
      "hash": "sha256-QHb+FxeCMFgc3QcYMjoDie7TeeN1qtueu8ZJ6/0khLQ=",
      "url": "_framework/System.Text.RegularExpressions.k7vpke4txz.wasm"
    },
    {
      "hash": "sha256-5uNPofYiMo6Fsvybdn9xpncYZtXGGdOc9MAZK2ZoW68=",
      "url": "_framework/System.Threading.Channels.mdjwqmcrfg.wasm"
    },
    {
      "hash": "sha256-9o1dqEKcerkaymttv9nnmaYtJ6T/0EEF85bhQ83fFVs=",
      "url": "_framework/System.Threading.Overlapped.68d0nhrxin.wasm"
    },
    {
      "hash": "sha256-UaV9oNK3Osb2nmk81b9/Hz+OjhFKCrjy2rKgIFSWXZ0=",
      "url": "_framework/System.Threading.Tasks.3vxtmtq8z2.wasm"
    },
    {
      "hash": "sha256-7lsw2tFBdjREWR6GzlB+zyAqXnPIE3h5OuTv2jbbkAs=",
      "url": "_framework/System.Threading.Tasks.Dataflow.ib1tcdxv3g.wasm"
    },
    {
      "hash": "sha256-VxL+yrkoY44U03HeoMUHYQOqoQyBNIEiZ+lPHgEwQ44=",
      "url": "_framework/System.Threading.Tasks.Extensions.fe58hhfni1.wasm"
    },
    {
      "hash": "sha256-iS4hh/OV/9+MtbUezobDlLCG85uESbTYt2kV4muGSng=",
      "url": "_framework/System.Threading.Tasks.Parallel.n02pnhiuoi.wasm"
    },
    {
      "hash": "sha256-XiMRppuabliDRz9bZgcGzg4BvnssK8+xw2kgYUUBCpQ=",
      "url": "_framework/System.Threading.Thread.ela0zpa4cu.wasm"
    },
    {
      "hash": "sha256-6G1zBNMKJD6pEwTpH/casLLUfLGprnW45bvXeTt0Pe8=",
      "url": "_framework/System.Threading.ThreadPool.456kqrtr37.wasm"
    },
    {
      "hash": "sha256-NEqURFacyG/0GIRYYNfxOtP4y480WslAxq8bYruhnkE=",
      "url": "_framework/System.Threading.Timer.8x28x1huyk.wasm"
    },
    {
      "hash": "sha256-WhYdkiL3qPpsBDZ40QfvhXN9xgPnhjKvm9S0ZE5CI2U=",
      "url": "_framework/System.Threading.e7dy3zxxc8.wasm"
    },
    {
      "hash": "sha256-On31WLYjoPrf/6nsyHzJKl9Wq7tpMWMkqht6dZY6PP4=",
      "url": "_framework/System.Transactions.Local.um51822t4e.wasm"
    },
    {
      "hash": "sha256-tGH9GNHgN9fzZ8J096pA7v5QiZL2vJixm+zsr60ylTI=",
      "url": "_framework/System.Transactions.grbj89ttaf.wasm"
    },
    {
      "hash": "sha256-zRNw40ZsSfnWa6rm7vMws7OjdCdjnlGkENcFFyrFrkc=",
      "url": "_framework/System.ValueTuple.ba8p6kmg8a.wasm"
    },
    {
      "hash": "sha256-0J+4ZF6llhJG5vLgkjbYv74mDvvVJGQzen7qeaRCy9o=",
      "url": "_framework/System.Web.HttpUtility.kz1rdswtnm.wasm"
    },
    {
      "hash": "sha256-rl4xSa6TYOpLgI31D8YNcxKULDJ87taQPqltjXF6M/U=",
      "url": "_framework/System.Web.ivo3eskvng.wasm"
    },
    {
      "hash": "sha256-yhDaei/WLYPm4b6n8N+p+Ljy52pNmKyutCpHaQ/8Fjs=",
      "url": "_framework/System.Windows.ipmhqe926s.wasm"
    },
    {
      "hash": "sha256-UVAEFHhgyu5szonQcT2NTdObuPPUjIWchk7ii5EaWL4=",
      "url": "_framework/System.Xml.1ortbls4va.wasm"
    },
    {
      "hash": "sha256-OFWisz47h0Ww5LEWwPE+kE+WAPF9l1dbSbi25RU0IRk=",
      "url": "_framework/System.Xml.Linq.kp3k7tm0gv.wasm"
    },
    {
      "hash": "sha256-PczobZAv4VRFTosy4OocVwpaLDTNofigcqzZ//MUOuQ=",
      "url": "_framework/System.Xml.ReaderWriter.52jfax1tqq.wasm"
    },
    {
      "hash": "sha256-quVluqY+9o+Qc2XL7OuKUKEz5guPdtRSupvcuKlBRiI=",
      "url": "_framework/System.Xml.Serialization.ue0pg3pj3d.wasm"
    },
    {
      "hash": "sha256-iUu171UBykxP8k5YGgm9iDndahEjJZMMHfVy1V6kDeI=",
      "url": "_framework/System.Xml.XDocument.1iommojzp6.wasm"
    },
    {
      "hash": "sha256-H7mENa8d7iBVbdHb/MNr1jt2njfZcDz+w16CF1XmBwg=",
      "url": "_framework/System.Xml.XPath.3bpkk2mjm4.wasm"
    },
    {
      "hash": "sha256-bLVyEPwO3VZFfE9A6cctQx9X0YlbPi4wtZG8CP83SiE=",
      "url": "_framework/System.Xml.XPath.XDocument.k25bvuxkbu.wasm"
    },
    {
      "hash": "sha256-n8cO9/kl8TgJcpCRDBZMncmWLE8BcW/jIYDmzoM3DDU=",
      "url": "_framework/System.Xml.XmlDocument.ni8e11ip1r.wasm"
    },
    {
      "hash": "sha256-IgCjgLemJBCcMw6razKvZQlSiLQGymK0+c+Y525jGPw=",
      "url": "_framework/System.Xml.XmlSerializer.me9902qi5t.wasm"
    },
    {
      "hash": "sha256-TKDL07npO9rYViOrL/X1uKIbZtgOwyfS3TlaTQ7QNEw=",
      "url": "_framework/System.ca8rpd37di.wasm"
    },
    {
      "hash": "sha256-ufB9Mo5joMyUs3DzXWWBFFIZNEVrt6h9N5stYB6Oln4=",
      "url": "_framework/WindowsBase.vy2l5u79y6.wasm"
    },
    {
      "hash": "sha256-6apXcfuIue9Fqj/P95um1/ZFZCln2ITKXet/0+efrqc=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-gD2XMSIt+vtDFirTg+LVASuuDVoOW3S7fY2a27Ou3Vs=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-IwCPMDwkWHz7KL51LHewflHuaaMBKJXaVNraKFCU7Fo=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-RtuwNrUOdAJ5A4aS4ZmceO4ySriaYqTdC7X++6yd9lM=",
      "url": "_framework/dotnet.native.21mns4qp4i.wasm"
    },
    {
      "hash": "sha256-oS7IRiQoVt9ThQ7Y2UM3XoeY0JqPD02cg9IvRdufn2w=",
      "url": "_framework/dotnet.native.9ih887ebfz.js"
    },
    {
      "hash": "sha256-P3ZPWa6Qo/AAAW3Ig5kk9qsoQWoZhgDFHpv3IRO/lkc=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-oBRKHAqZUsvCRnCzkQfB7zc45cpKLNq2NKyrG10IKx8=",
      "url": "_framework/dotnet.runtime.st3wwc8rqy.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-1YSLR2eZt3ceALFV//vZUF2AloxVil3VlrW1zZYPSEI=",
      "url": "_framework/mscorlib.xd6mv31d55.wasm"
    },
    {
      "hash": "sha256-HLEwBpLfzKw2/zGSVzHzFJxznCkt/WIjahrziiMrOpA=",
      "url": "_framework/netstandard.kaml52uspo.wasm"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-lfVaYNXZK/TnPfDiXAl3Sksn+R+81EY5sXMicssNUmE=",
      "url": "index.html"
    },
    {
      "hash": "sha256-f4c8YV1qrr6RSiVYWMQT7R5W2OkT+iXmE5H69/uRvGQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-hN2ttMG/K3wQlFrN3SbQ1YF4tIJHCE4oYP+QibT3vOY=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-M15fHTKfMK6cTars5c28PNhN6hD0qeUb3HPzOdoPwCc=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-+rGG3u63SMkHL80Ga42LAawPUj7i8vaR2Kuenqlta2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-rjusxCRzKjztCcfgOVduAc3e3Z7KvimJGokJSeADNmE=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-y72bT5TKmFmfvw3bNEzPRNZa/8595xtseZIcBUV0PdM=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-gRKIHVkBgnCPUs/hmZsXynZ9ZJpvsE77idtljDkrWGI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-UkajePbMzGj8y73Imkd3dWWnLJr0v2CrBCLMrVMleP8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-uIzOR4gILoNjCGNryIsWnkEGO3BSwRa/MLjr73tDodE=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-ZBXbYF8OZrF1GDOLMLvW/zRPtx1RfeMDYj5D2Wb/9jo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-MwFckg8YbY2WrveNQnXkfULkprYhFOq+t1BH92A7GsI=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-7MYEMUFgHEc1CjrfAK/TlV30POxgoxXk2b+vAs/143U=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-CzmECrtXV8BSk/+8SG+Rw7Fr+3hCt2bS2bEkS4YD3PQ=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-sKIQRfQriISuQ9l/44b1zHfQniGXJhGonVtB2LlSuIs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-/rceNUMI0RlFJugRzjua815bgXwawEJBGBPh4Vx3r38=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-rI1w2GDxZPCr77bpZIGQ8mUvMVtEr+gBtahl5RIPJpA=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-1oGvJhJSeR+r7iw+zyN0NcsO1lsb3aedJTWmOquPONY=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-4TjJb1O1r2r1Nf9VdaYyCZnNylQNDgpQE5heNzG9i7s=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-6zfk2L8R3wCgRbZzpkEi7UYC2bc6fYGIgFfNeqyOWnQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-2ZJt2kDu1xdShLusFPrRVH0DpsNStHDLDbuEQ+rqK80=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-7AOJkSa5Id9lj6XCmbSwoA4tCOdtwU0lUnXFYXOwDkM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-br3dWEzqedAZMLxh9uTvoK34YzffJupyIuJBHyORXyY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-REjSeieVKd00nAKwd6dv7MMhuVKvKctPmLI4iDRs/cc=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-70DIvAQ5eyFoHA4yVe3VFb9hXmNSlhzWkNSy32ROCO4=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-7vFFm2I6Rj4GeqMI92sXbjU0uDgoYAMILvWFa9Md9ak=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-dOJIOn9Vl8UgXx4ky14juP9iAMIs0kv5Q26jVjJPJps=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-aCTIqw9op0XQGYnNe1649V7fnihACD48OP3M8BP2xVM=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-yE3IJQyS/wcakDK5oKOqJ5CppA1utUAha+LQSssKnvA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-O36vRExifFa1cgIw/Sadf6xJrivlPCJLyG1YrhrV87k=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
